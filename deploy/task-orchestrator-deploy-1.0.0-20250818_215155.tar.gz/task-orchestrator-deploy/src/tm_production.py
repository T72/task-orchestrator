#!/usr/bin/env python3
"""
Task Orchestrator with Context Sharing - Production Version
Simple interface for multi-agent task coordination with automatic cleanup
"""

import sys
import os
import json
import sqlite3
import argparse
import uuid
import fcntl
import shutil
import tarfile
from datetime import datetime, timedelta
from pathlib import Path
from typing import List, Optional, Dict, Any
import hashlib
import yaml
import time

# Internal constants - not exposed to users
_DEFAULT_RETENTION_DAYS = 30
_AUTO_CLEANUP = True
_COMPRESS_ARCHIVES = True
_MAX_CONTEXT_SIZE_MB = 10

class TaskManager:
    """Simple task manager for multi-agent coordination"""
    
    def __init__(self):
        self.repo_root = self._find_repo_root()
        self.db_dir = self.repo_root / ".task-orchestrator"
        self.db_path = self.db_dir / "tasks.db"
        self.agent_id = os.environ.get('TM_AGENT_ID', self._generate_agent_id())
        self._init_db()
    
    def _find_repo_root(self) -> Path:
        """Find git repository root"""
        try:
            import subprocess
            result = subprocess.run(
                ["git", "rev-parse", "--show-toplevel"],
                capture_output=True, text=True, check=True
            )
            return Path(result.stdout.strip())
        except:
            return Path.cwd()
    
    def _generate_agent_id(self) -> str:
        """Generate unique agent ID"""
        unique = f"{os.getpid()}:{os.environ.get('USER', 'agent')}"
        return hashlib.md5(unique.encode()).hexdigest()[:8]
    
    def _init_db(self):
        """Initialize database if needed"""
        self.db_dir.mkdir(parents=True, exist_ok=True)
        
        # Initialize subdirectories
        (self.db_dir / "contexts").mkdir(exist_ok=True)
        (self.db_dir / "notes").mkdir(exist_ok=True)
        (self.db_dir / "archives").mkdir(exist_ok=True)
        
        with sqlite3.connect(str(self.db_path)) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS tasks (
                    id TEXT PRIMARY KEY,
                    title TEXT NOT NULL,
                    description TEXT,
                    status TEXT DEFAULT 'pending',
                    priority TEXT DEFAULT 'medium',
                    assignee TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    completed_at TEXT
                )
            """)
            
            conn.execute("""
                CREATE TABLE IF NOT EXISTS dependencies (
                    task_id TEXT NOT NULL,
                    depends_on TEXT NOT NULL,
                    PRIMARY KEY (task_id, depends_on)
                )
            """)
            
            conn.execute("""
                CREATE TABLE IF NOT EXISTS participants (
                    task_id TEXT NOT NULL,
                    agent_id TEXT NOT NULL,
                    joined_at TEXT NOT NULL,
                    PRIMARY KEY (task_id, agent_id)
                )
            """)
            
            conn.commit()
    
    # ========== SIMPLE PUBLIC INTERFACE ==========
    
    def add(self, title: str, description: str = None, 
            priority: str = "medium", depends_on: List[str] = None) -> str:
        """Add a new task"""
        task_id = uuid.uuid4().hex[:8]
        now = datetime.now().isoformat()
        
        with sqlite3.connect(str(self.db_path)) as conn:
            # Determine status based on dependencies
            status = "blocked" if depends_on else "pending"
            
            conn.execute("""
                INSERT INTO tasks (id, title, description, status, priority, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (task_id, title, description, status, priority, now, now))
            
            # Add dependencies
            if depends_on:
                for dep_id in depends_on:
                    conn.execute("""
                        INSERT INTO dependencies (task_id, depends_on)
                        VALUES (?, ?)
                    """, (task_id, dep_id))
            
            conn.commit()
        
        # Auto-initialize context for collaboration
        self._init_context(task_id, title)
        
        return task_id
    
    def update(self, task_id: str, status: str = None, assignee: str = None) -> bool:
        """Update task status or assignment"""
        now = datetime.now().isoformat()
        updates = ["updated_at = ?"]
        params = [now]
        
        if status:
            updates.append("status = ?")
            params.append(status)
        
        if assignee:
            updates.append("assignee = ?")
            params.append(assignee)
        
        params.append(task_id)
        
        with sqlite3.connect(str(self.db_path)) as conn:
            conn.execute(f"""
                UPDATE tasks 
                SET {', '.join(updates)}
                WHERE id = ?
            """, params)
            conn.commit()
        
        return True
    
    def complete(self, task_id: str) -> bool:
        """Complete a task and trigger auto-cleanup"""
        now = datetime.now().isoformat()
        
        with sqlite3.connect(str(self.db_path)) as conn:
            conn.execute("""
                UPDATE tasks 
                SET status = 'completed', completed_at = ?
                WHERE id = ?
            """, (now, task_id))
            
            # Unblock dependent tasks
            conn.execute("""
                UPDATE tasks 
                SET status = 'pending'
                WHERE status = 'blocked' 
                AND id IN (
                    SELECT task_id FROM dependencies 
                    WHERE depends_on = ?
                    AND NOT EXISTS (
                        SELECT 1 FROM dependencies d2
                        JOIN tasks t ON d2.depends_on = t.id
                        WHERE d2.task_id = dependencies.task_id
                        AND d2.depends_on != ?
                        AND t.status != 'completed'
                    )
                )
            """, (task_id, task_id))
            
            conn.commit()
        
        # Auto archive and cleanup
        if _AUTO_CLEANUP:
            self._archive_and_cleanup(task_id)
        
        return True
    
    def list(self, status: str = None, assignee: str = None) -> List[Dict]:
        """List tasks with optional filters"""
        query = "SELECT * FROM tasks WHERE 1=1"
        params = []
        
        if status:
            query += " AND status = ?"
            params.append(status)
        
        if assignee:
            query += " AND assignee = ?"
            params.append(assignee)
        
        query += " ORDER BY created_at DESC"
        
        with sqlite3.connect(str(self.db_path)) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.execute(query, params)
            return [dict(row) for row in cursor.fetchall()]
    
    def join(self, task_id: str) -> bool:
        """Join a task's collaborative context"""
        now = datetime.now().isoformat()
        
        with sqlite3.connect(str(self.db_path)) as conn:
            conn.execute("""
                INSERT OR REPLACE INTO participants (task_id, agent_id, joined_at)
                VALUES (?, ?, ?)
            """, (task_id, self.agent_id, now))
            conn.commit()
        
        # Ensure context exists
        context_path = self.db_dir / "contexts" / f"{task_id}.yaml"
        if not context_path.exists():
            with sqlite3.connect(str(self.db_path)) as conn:
                cursor = conn.execute("SELECT title FROM tasks WHERE id = ?", (task_id,))
                row = cursor.fetchone()
                if row:
                    self._init_context(task_id, row[0])
        
        return True
    
    def note(self, task_id: str, content: str) -> bool:
        """Add private notes for a task"""
        notes_path = self.db_dir / "notes" / f"{task_id}_{self.agent_id}.md"
        
        # Append with timestamp
        with open(notes_path, 'a') as f:
            if notes_path.stat().st_size > 0:
                f.write(f"\n\n---\n{datetime.now().isoformat()}\n")
            f.write(content)
        
        return True
    
    def share(self, task_id: str, content: str, type: str = "update") -> bool:
        """Share information with other agents on the task"""
        context_path = self.db_dir / "contexts" / f"{task_id}.yaml"
        
        # Ensure we've joined the task
        self.join(task_id)
        
        # Load context
        if context_path.exists():
            with open(context_path, 'r') as f:
                context = yaml.safe_load(f) or {}
        else:
            context = {}
        
        # Add contribution
        if "contributions" not in context:
            context["contributions"] = []
        
        context["contributions"].append({
            "agent": self.agent_id,
            "timestamp": datetime.now().isoformat(),
            "type": type,
            "content": content
        })
        
        # Keep only last 100 contributions to prevent bloat
        if len(context["contributions"]) > 100:
            context["contributions"] = context["contributions"][-100:]
        
        # Save context
        with open(context_path, 'w') as f:
            yaml.dump(context, f, default_flow_style=False)
        
        return True
    
    def sync(self, task_id: str, checkpoint: str) -> bool:
        """Create a synchronization point"""
        return self.share(task_id, checkpoint, type="sync")
    
    def discover(self, task_id: str, finding: str) -> bool:
        """Share an important discovery"""
        return self.share(task_id, finding, type="discovery")
    
    def context(self, task_id: str) -> Dict:
        """Get task context (both shared and private)"""
        result = {"task_id": task_id}
        
        # Get shared context
        context_path = self.db_dir / "contexts" / f"{task_id}.yaml"
        if context_path.exists():
            with open(context_path, 'r') as f:
                result["shared"] = yaml.safe_load(f)
        
        # Get private notes
        notes_path = self.db_dir / "notes" / f"{task_id}_{self.agent_id}.md"
        if notes_path.exists():
            with open(notes_path, 'r') as f:
                result["notes"] = f.read()
        
        return result
    
    # ========== INTERNAL METHODS (Hidden from users) ==========
    
    def _init_context(self, task_id: str, title: str):
        """Initialize context for a task"""
        context_path = self.db_dir / "contexts" / f"{task_id}.yaml"
        if not context_path.exists():
            context = {
                "task_id": task_id,
                "title": title,
                "created": datetime.now().isoformat(),
                "contributions": []
            }
            with open(context_path, 'w') as f:
                yaml.dump(context, f, default_flow_style=False)
    
    def _archive_and_cleanup(self, task_id: str):
        """Archive and cleanup completed task files"""
        try:
            # Create archive
            archive_dir = self.db_dir / "archives"
            archive_dir.mkdir(exist_ok=True)
            
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            archive_name = f"task_{task_id}_{timestamp}"
            
            if _COMPRESS_ARCHIVES:
                archive_path = archive_dir / f"{archive_name}.tar.gz"
                with tarfile.open(archive_path, 'w:gz') as tar:
                    # Add context file
                    context_file = self.db_dir / "contexts" / f"{task_id}.yaml"
                    if context_file.exists():
                        tar.add(context_file, arcname=f"{archive_name}/context.yaml")
                        context_file.unlink()
                    
                    # Add all notes files for this task
                    for notes_file in (self.db_dir / "notes").glob(f"{task_id}_*.md"):
                        tar.add(notes_file, arcname=f"{archive_name}/notes/{notes_file.name}")
                        notes_file.unlink()
            
            # Schedule cleanup of old archives
            self._cleanup_old_archives()
            
        except Exception:
            pass  # Silently handle cleanup errors
    
    def _cleanup_old_archives(self):
        """Remove archives older than retention period"""
        try:
            cutoff = datetime.now() - timedelta(days=_DEFAULT_RETENTION_DAYS)
            archive_dir = self.db_dir / "archives"
            
            for archive in archive_dir.glob("*.tar.gz"):
                # Parse timestamp from filename
                parts = archive.stem.split('_')
                if len(parts) >= 3:
                    date_str = parts[-2] + parts[-1]
                    try:
                        file_date = datetime.strptime(date_str, "%Y%m%d%H%M%S")
                        if file_date < cutoff:
                            archive.unlink()
                    except:
                        pass
        except Exception:
            pass


def main():
    """Simple CLI interface"""
    parser = argparse.ArgumentParser(
        description="Task Orchestrator - Simple multi-agent coordination",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  tm add "Build API"                    # Create task
  tm list                               # List all tasks
  tm join abc123                        # Join task collaboration
  tm share abc123 "API design ready"    # Share with team
  tm complete abc123                    # Complete and auto-cleanup
        """
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Commands")
    
    # Add task
    add_parser = subparsers.add_parser("add", help="Add new task")
    add_parser.add_argument("title", help="Task title")
    add_parser.add_argument("-d", "--description", help="Description")
    add_parser.add_argument("-p", "--priority", choices=["low", "medium", "high"], default="medium")
    add_parser.add_argument("--depends-on", nargs="+", help="Task dependencies")
    
    # List tasks
    list_parser = subparsers.add_parser("list", help="List tasks")
    list_parser.add_argument("--status", help="Filter by status")
    list_parser.add_argument("--assignee", help="Filter by assignee")
    
    # Update task
    update_parser = subparsers.add_parser("update", help="Update task")
    update_parser.add_argument("task_id", help="Task ID")
    update_parser.add_argument("--status", choices=["pending", "in_progress", "blocked"])
    update_parser.add_argument("--assignee", help="Assign to agent")
    
    # Complete task
    complete_parser = subparsers.add_parser("complete", help="Complete task")
    complete_parser.add_argument("task_id", help="Task ID")
    
    # Join task
    join_parser = subparsers.add_parser("join", help="Join task collaboration")
    join_parser.add_argument("task_id", help="Task ID")
    
    # Add note
    note_parser = subparsers.add_parser("note", help="Add private note")
    note_parser.add_argument("task_id", help="Task ID")
    note_parser.add_argument("content", help="Note content")
    
    # Share update
    share_parser = subparsers.add_parser("share", help="Share with team")
    share_parser.add_argument("task_id", help="Task ID")
    share_parser.add_argument("content", help="Content to share")
    
    # Sync point
    sync_parser = subparsers.add_parser("sync", help="Create sync point")
    sync_parser.add_argument("task_id", help="Task ID")
    sync_parser.add_argument("checkpoint", help="Checkpoint description")
    
    # Discovery
    discover_parser = subparsers.add_parser("discover", help="Share discovery")
    discover_parser.add_argument("task_id", help="Task ID")
    discover_parser.add_argument("finding", help="Discovery description")
    
    # View context
    context_parser = subparsers.add_parser("context", help="View task context")
    context_parser.add_argument("task_id", help="Task ID")
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return
    
    tm = TaskManager()
    
    if args.command == "add":
        task_id = tm.add(args.title, args.description, args.priority, args.depends_on)
        print(f"Created task: {task_id}")
    
    elif args.command == "list":
        tasks = tm.list(args.status, args.assignee)
        for task in tasks:
            status_icon = "✓" if task["status"] == "completed" else "○"
            print(f"{status_icon} {task['id']}: {task['title']} [{task['status']}]")
    
    elif args.command == "update":
        tm.update(args.task_id, args.status, args.assignee)
        print(f"Updated task: {args.task_id}")
    
    elif args.command == "complete":
        tm.complete(args.task_id)
        print(f"Completed task: {args.task_id}")
    
    elif args.command == "join":
        tm.join(args.task_id)
        print(f"Joined task: {args.task_id}")
    
    elif args.command == "note":
        tm.note(args.task_id, args.content)
        print("Note added")
    
    elif args.command == "share":
        tm.share(args.task_id, args.content)
        print("Shared with team")
    
    elif args.command == "sync":
        tm.sync(args.task_id, args.checkpoint)
        print(f"Sync point created: {args.checkpoint}")
    
    elif args.command == "discover":
        tm.discover(args.task_id, args.finding)
        print("Discovery shared")
    
    elif args.command == "context":
        context = tm.context(args.task_id)
        print(f"Task: {args.task_id}")
        if "shared" in context:
            print("\nShared Context:")
            contributions = context["shared"].get("contributions", [])
            for contrib in contributions[-5:]:  # Show last 5
                print(f"  [{contrib['type']}] {contrib['agent']}: {contrib['content']}")
        if "notes" in context:
            print("\nYour Notes:")
            print(context["notes"][:500])  # Show first 500 chars


if __name__ == "__main__":
    main()